package com.visionclicker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.visionclicker.AppContainer
import com.visionclicker.model.AppRuntime
import com.visionclicker.util.PermissionState
import kotlin.math.roundToInt

/**
 * Вкладка «Слежение»: когда объект найден, анализ идёт только вокруг него.
 * Окно едет за объектом и не ограничено зоной, которую задал пользователь.
 */
@Composable
fun TrackingScreen(perms: PermissionState, container: AppContainer) {
    val repo = container.settings
    val settings by repo.settings.collectAsState()
    val state by AppRuntime.state.collectAsState()
    val paused by AppRuntime.paused.collectAsState()
    val present by AppRuntime.objectPresent.collectAsState()
    val wide by AppRuntime.trackingWide.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Слежение", style = MaterialTheme.typography.headlineMedium)

        SectionCard("Режим слежения") {
            SwitchRow(
                title = "Следить за объектом",
                checked = settings.trackObject
            ) { v -> repo.update { it.copy(trackObject = v) } }
            HintText(
                "Когда объект найден, анализ идёт только в его окрестности и движется вместе с ним, " +
                    "куда бы он ни переместился. Зона, заданная на вкладке «Область», нужна только для первого поиска."
            )
            HintText(
                "Если объект выскочил из окна (быстрое движение), приложение ищет его по всему экрану, " +
                    "пока не найдёт снова."
            )
        }

        SectionCard("Запас вокруг объекта") {
            SliderRow(
                title = "Запас",
                value = settings.trackMarginPct * 100f,
                range = 5f..100f,
                valueText = "${(settings.trackMarginPct * 100).roundToInt()}%"
            ) { v -> repo.update { it.copy(trackMarginPct = v / 100f) } }
            HintText(
                "Насколько далеко от объекта ищется его продолжение за один кадр. " +
                    "Больше запас — надёжнее при быстром движении, но выше нагрузка на процессор."
            )
        }

        SectionCard("Статус") {
            StateBadge(state, paused)
            HintText(statusText(state.isRunning, settings.trackObject, present, wide))
        }
    }
}

private fun statusText(running: Boolean, tracking: Boolean, present: Boolean, wide: Boolean): String = when {
    !running -> "Запустите мониторинг на вкладке «Главная», чтобы слежение заработало."
    !tracking -> "Слежение выключено: поиск только в заданной области."
    wide -> "Объект вне окна слежения — ищем по всему экрану."
    present -> "Объект зафиксирован: зона следует за ним."
    else -> "Ищем объект в заданной области."
}
