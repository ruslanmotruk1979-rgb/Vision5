package com.visionclicker.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.visionclicker.AppContainer
import com.visionclicker.CaptureRequestActivity
import com.visionclicker.container
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.MonitoringState
import com.visionclicker.overlay.FloatingOverlayService
import com.visionclicker.util.PermissionState
import com.visionclicker.util.Permissions
import kotlin.math.roundToInt

private data class Tab(val title: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("Главная", Icons.Filled.Home),
    Tab("Шаблон", Icons.Filled.Search),
    Tab("Область", Icons.Filled.LocationOn),
    Tab("Слежение", Icons.Filled.Refresh),
    Tab("Кликер", Icons.Filled.PlayArrow),
    Tab("Настройки", Icons.Filled.Settings)
)

@Composable
fun VisionClickerRoot(resumeTick: Int) {
    val ctx = LocalContext.current
    val container = remember { ctx.container }
    var tab by remember { mutableIntStateOf(0) }
    val perms = remember(resumeTick) { Permissions.read(ctx) }
    val pending by AppRuntime.pendingScreenshot.collectAsState()

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !perms.notifications) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    // Снимок экрана готов — открываем вкладку «Шаблон» с редактором обрезки
    LaunchedEffect(pending) { if (pending) tab = 1 }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            when (tab) {
                0 -> HomeScreen(perms, container)
                1 -> TemplateScreen(container)
                2 -> RegionScreen(perms, container)
                3 -> TrackingScreen(perms, container)
                4 -> ClickerScreen(perms, container)
                else -> SettingsScreen(perms, container)
            }
        }
    }
}

@Composable
fun HomeScreen(perms: PermissionState, container: AppContainer) {
    val ctx = LocalContext.current
    val repo = container.settings
    val settings by repo.settings.collectAsState()
    val state by AppRuntime.state.collectAsState()
    val paused by AppRuntime.paused.collectAsState()
    val error by AppRuntime.errorMessage.collectAsState()
    val clicks by AppRuntime.clickCount.collectAsState()
    val score by AppRuntime.lastScore.collectAsState()
    val ms by AppRuntime.analysisMs.collectAsState()
    val note by AppRuntime.matcherNote.collectAsState()
    val overlayOn by AppRuntime.overlayRunning.collectAsState()
    val panelHidden by AppRuntime.panelHidden.collectAsState()
    val tplVersion by repo.templateVersion.collectAsState()
    val region by container.regions.region.collectAsState()
    val screen by AppRuntime.screen.collectAsState()
    val templates by repo.templates.collectAsState()
    val enabledTpl = templates.filter { it.enabled }
    val template = remember(tplVersion, templates) { enabledTpl.firstOrNull()?.let { repo.loadTemplate(it.id) } }
    var showWarning by remember { mutableStateOf(false) }

    fun doStart() {
        if (settings.autoShowPanel && perms.overlay) {
            AppRuntime.panelHidden.value = false
            FloatingOverlayService.start(ctx)
        }
        ctx.startActivity(Intent(ctx, CaptureRequestActivity::class.java))
    }

    fun requestStart() {
        when {
            !repo.hasEnabledTemplate() -> toastLong(ctx, "Сначала добавьте и включите шаблон: вкладка «Шаблон»")
            !perms.overlay -> {
                toastLong(ctx, "Нужно разрешение «Поверх других приложений»")
                Permissions.openOverlaySettings(ctx)
            }
            settings.clickerEnabled && !perms.accessibility -> {
                toastLong(ctx, "Включите службу «Vision Clicker» в разделе «Специальные возможности»")
                Permissions.openAccessibilitySettings(ctx)
            }
            !settings.warningAccepted -> showWarning = true
            else -> doStart()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Vision Clicker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard("Состояние системы") {
            StateBadge(state, paused)
            val err = error
            if (state == MonitoringState.ERROR && err != null) {
                Text(err, color = VcColors.bad)
            }
            if (state.isRunning) {
                HintText(
                    "Совпадение ${(score * 100).toInt()}% (порог ${(settings.threshold * 100).toInt()}%) · " +
                        "анализ $ms мс · нажатий: $clicks"
                )
            }
            note?.let { HintText(it, VcColors.warn) }
        }

        if (!perms.required) {
            SectionCard("Нужны разрешения") {
                PermissionRow(
                    "Поверх других приложений", perms.overlay,
                    "Для панели, рамки области и маркера", "Включить"
                ) { Permissions.openOverlaySettings(ctx) }
                PermissionRow(
                    "Служба нажатий", perms.accessibility,
                    "Специальные возможности → Vision Clicker", "Включить"
                ) { Permissions.openAccessibilitySettings(ctx) }
            }
        }

        SectionCard("Текущая настройка") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (template != null) {
                    Image(
                        bitmap = template.asImageBitmap(),
                        contentDescription = "Шаблон",
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                }
                Column {
                    Text(
                        if (enabledTpl.isNotEmpty()) "Активных шаблонов: ${enabledTpl.size}" else "Шаблон не выбран",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    if (enabledTpl.isNotEmpty()) HintText(enabledTpl.joinToString(", ") { it.name })
                    HintText("${settings.matchMode.title} · порог ${(settings.threshold * 100).toInt()}%")
                }
            }
            val regionText = if (settings.fullScreen) {
                "весь экран"
            } else {
                "x=${region.left}, y=${region.top}, ${region.width}×${region.height} px"
            }
            Text("Область: $regionText", style = MaterialTheme.typography.bodyMedium)
            val pt = settings.clickerFor(screen.isLandscape)
            val cx = (pt.x * screen.width).roundToInt()
            val cy = (pt.y * screen.height).roundToInt()
            val clickText = if (settings.clickerEnabled) {
                "(${cx}, ${cy}) · ${settings.clickMode.title.lowercase()} · ${settings.clickIntervalMs} мс"
            } else {
                "выключен"
            }
            Text("Кликер: $clickText", style = MaterialTheme.typography.bodyMedium)
        }

        BigButton(
            text = if (state.isRunning) "Остановить мониторинг" else "Запустить мониторинг",
            color = if (state.isRunning) VcColors.warn else VcColors.ok
        ) {
            if (state.isRunning) emergencyStop() else requestStart()
        }

        OutlinedButton(
            onClick = {
                if (overlayOn && !panelHidden) {
                    FloatingOverlayService.close(ctx)
                } else if (!perms.overlay) {
                    toastLong(ctx, "Сначала выдайте разрешение «Поверх других приложений»")
                    Permissions.openOverlaySettings(ctx)
                } else {
                    AppRuntime.panelHidden.value = false
                    FloatingOverlayService.start(ctx)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (overlayOn && !panelHidden) "Закрыть плавающую панель" else "Показать плавающую панель")
        }

        EmergencyButton()

        HintText(
            "Во время работы приложение нажимает на экран поверх других приложений. " +
                "Остановить можно в любой момент: панель, уведомление или кнопка выше.",
            VcColors.warn
        )
    }

    if (showWarning) {
        AlertDialog(
            onDismissRequest = { showWarning = false },
            title = { Text("Важно") },
            text = {
                Text(
                    "Во время работы приложение выполняет нажатия ПОВЕРХ ДРУГИХ ПРИЛОЖЕНИЙ " +
                        "в заданной вами точке, пока выбранный объект виден в области. " +
                        "Следите, что находится под маркером.\n\n" +
                        "Остановить можно в любой момент: кнопка «Стоп» на панели, " +
                        "кнопка в уведомлении или «Экстренная остановка»."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showWarning = false
                    repo.update { it.copy(warningAccepted = true) }
                    doStart()
                }) { Text("Понимаю, запустить") }
            },
            dismissButton = { TextButton(onClick = { showWarning = false }) { Text("Отмена") } }
        )
    }
}
