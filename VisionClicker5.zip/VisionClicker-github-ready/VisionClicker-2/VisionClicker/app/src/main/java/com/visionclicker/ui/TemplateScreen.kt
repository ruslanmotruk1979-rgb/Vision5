package com.visionclicker.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.visionclicker.AppContainer
import com.visionclicker.CaptureRequestActivity
import com.visionclicker.data.SettingsRepository
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.MatchMode
import com.visionclicker.model.TemplateItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private fun decodeBitmap(ctx: Context, uri: Uri): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
    val opts = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
} catch (e: Exception) {
    null
}

@Composable
fun TemplateScreen(container: AppContainer) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = container.settings
    val settings by repo.settings.collectAsState()
    val templates by repo.templates.collectAsState()
    val tplVersion by repo.templateVersion.collectAsState()
    val pending by AppRuntime.pendingScreenshot.collectAsState()
    val score by AppRuntime.lastScore.collectAsState()
    val ms by AppRuntime.analysisMs.collectAsState()
    val note by AppRuntime.matcherNote.collectAsState()
    val state by AppRuntime.state.collectAsState()
    var cropSource by remember { mutableStateOf<Bitmap?>(null) }
    var renameTarget by remember { mutableStateOf<TemplateItem?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { decodeBitmap(ctx, uri) }
                if (bmp != null) {
                    cropSource = bmp
                } else {
                    toastLong(ctx, "Не удалось открыть изображение")
                }
            }
        }
    }

    // Снимок, сделанный самим приложением, готов — открываем обрезку
    LaunchedEffect(pending) {
        if (pending) {
            val bmp = withContext(Dispatchers.IO) { repo.loadScreenshot() }
            AppRuntime.pendingScreenshot.value = false
            if (bmp != null) cropSource = bmp
        }
    }

    val src = cropSource
    if (src != null) {
        CropEditor(
            source = src,
            onCancel = { cropSource = null },
            onDone = { cropped ->
                repo.addTemplate(cropped)
                cropSource = null
                toast(ctx, "Шаблон добавлен")
            }
        )
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Шаблоны", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

            SectionCard("Объекты для поиска") {
                if (templates.isEmpty()) {
                    HintText("Шаблонов пока нет. Добавьте хотя бы один.")
                } else {
                    HintText(
                        "Включённые шаблоны ищутся одновременно. Совпадение любого из них " +
                            "запускает клики. Переключатель — вкл/выкл, название — переименовать."
                    )
                }

                for (t in templates) {
                    TemplateRow(t, repo, tplVersion) { renameTarget = it }
                }

                Button(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Добавить из галереи") }

                FilledTonalButton(
                    onClick = {
                        toastLong(ctx, "Подтвердите захват, затем откройте нужный экран — снимок будет через 5 секунд")
                        ctx.startActivity(
                            Intent(ctx, CaptureRequestActivity::class.java)
                                .putExtra(CaptureRequestActivity.EXTRA_SNAPSHOT, true)
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Снимок экрана и добавить (через 5 с)") }

                HintText(
                    "После снимка откройте нужный экран — кадр сохранится сам, затем обрежьте объект рамкой."
                )
            }

            SectionCard("Распознавание") {
                SliderRow(
                    title = "Порог совпадения",
                    value = settings.threshold * 100f,
                    range = 50f..99f,
                    valueText = "${(settings.threshold * 100).roundToInt()}%",
                    steps = 48
                ) { v -> repo.update { it.copy(threshold = v.roundToInt() / 100f) } }
                HintText("Выше порог — меньше ложных срабатываний, но объект легче «потерять».")

                Text("Режим обнаружения", style = MaterialTheme.typography.titleSmall)
                for (m in MatchMode.values()) {
                    RadioRow(m.title, m.hint, settings.matchMode == m) {
                        repo.update { it.copy(matchMode = m) }
                    }
                }

                SliderRow(
                    title = "Минимальный размер объекта",
                    value = settings.minObjectSizePx.toFloat(),
                    range = 4f..300f,
                    valueText = "${settings.minObjectSizePx} px"
                ) { v -> repo.update { it.copy(minObjectSizePx = v.roundToInt()) } }

                SwitchRow(
                    title = "Рамка вокруг найденного объекта",
                    checked = settings.showDetectionBox
                ) { v -> repo.update { it.copy(showDetectionBox = v) } }
            }

            if (state.isRunning) {
                SectionCard("Диагностика") {
                    HintText("Последнее совпадение: ${(score * 100).toInt()}% · анализ $ms мс")
                    note?.let { HintText(it, VcColors.warn) }
                }
            }
        }
    }

    renameTarget?.let { t ->
        RenameDialog(
            item = t,
            onSave = { name ->
                repo.renameTemplate(t.id, name)
                renameTarget = null
            },
            onDismiss = { renameTarget = null }
        )
    }
}

@Composable
private fun TemplateRow(
    item: TemplateItem,
    repo: SettingsRepository,
    version: Int,
    onRename: (TemplateItem) -> Unit
) {
    val bmp = remember(item.id, version) { repo.loadTemplate(item.id) }
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = item.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(56.dp)
            )
        }
        Column(Modifier.weight(1f).clickable { onRename(item) }) {
            Text(item.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            HintText(
                if (bmp != null) "${bmp.width}×${bmp.height} px · нажмите, чтобы переименовать"
                else "Файл не найден"
            )
        }
        Switch(checked = item.enabled, onCheckedChange = { repo.setTemplateEnabled(item.id, it) })
        TextButton(onClick = { repo.deleteTemplate(item.id) }) { Text("Удалить") }
    }
}

@Composable
private fun RenameDialog(item: TemplateItem, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Название объекта") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(30) },
                singleLine = true,
                label = { Text("Название") }
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim().ifEmpty { item.name }) }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
