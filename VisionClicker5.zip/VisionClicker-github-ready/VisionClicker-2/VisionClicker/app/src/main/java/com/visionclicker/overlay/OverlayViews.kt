package com.visionclicker.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import com.visionclicker.model.RegionHandle
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class Glyph { PLAY, PAUSE, STOP, GEAR, MINIMIZE, CLOSE, TARGET, REGION, EYE, CAMERA }

/** Кнопка-иконка, нарисованная кодом (не зависит от шрифтов и ресурсов). */
class GlyphButton(context: Context, private val glyph: Glyph) : View(context) {

    var accent: Int = 0xFF4DD0E1.toInt()
        set(value) {
            field = value
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val density = resources.displayMetrics.density

    init {
        isClickable = true
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (40 * density).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val u = w / 40f
        val cx = w / 2f
        val cy = h / 2f

        p.pathEffect = null
        p.style = Paint.Style.FILL
        p.color = if (isActivated) 0x554DD0E1 else 0x22FFFFFF
        c.drawRoundRect(3 * u, 3 * u, w - 3 * u, h - 3 * u, 10 * u, 10 * u, p)

        val ink = when {
            !isEnabled -> 0x55FFFFFF
            isActivated -> accent
            else -> Color.WHITE
        }
        p.color = ink
        p.strokeWidth = 2.6f * u
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        when (glyph) {
            Glyph.PLAY -> {
                path.reset()
                path.moveTo(cx - 5 * u, cy - 8 * u)
                path.lineTo(cx - 5 * u, cy + 8 * u)
                path.lineTo(cx + 8 * u, cy)
                path.close()
                p.style = Paint.Style.FILL
                c.drawPath(path, p)
            }
            Glyph.PAUSE -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(cx - 8 * u, cy - 8 * u, cx - 2.5f * u, cy + 8 * u, u, u, p)
                c.drawRoundRect(cx + 2.5f * u, cy - 8 * u, cx + 8 * u, cy + 8 * u, u, u, p)
            }
            Glyph.STOP -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(cx - 7 * u, cy - 7 * u, cx + 7 * u, cy + 7 * u, 2 * u, 2 * u, p)
            }
            Glyph.GEAR -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, 6 * u, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val ca = cos(a).toFloat()
                    val sa = sin(a).toFloat()
                    c.drawLine(cx + ca * 9 * u, cy + sa * 9 * u, cx + ca * 12 * u, cy + sa * 12 * u, p)
                }
            }
            Glyph.MINIMIZE -> {
                p.style = Paint.Style.STROKE
                c.drawLine(cx - 8 * u, cy + 5 * u, cx + 8 * u, cy + 5 * u, p)
            }
            Glyph.CLOSE -> {
                p.style = Paint.Style.STROKE
                c.drawLine(cx - 7 * u, cy - 7 * u, cx + 7 * u, cy + 7 * u, p)
                c.drawLine(cx + 7 * u, cy - 7 * u, cx - 7 * u, cy + 7 * u, p)
            }
            Glyph.TARGET -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, 7 * u, p)
                c.drawLine(cx, cy - 13 * u, cx, cy - 8 * u, p)
                c.drawLine(cx, cy + 8 * u, cx, cy + 13 * u, p)
                c.drawLine(cx - 13 * u, cy, cx - 8 * u, cy, p)
                c.drawLine(cx + 8 * u, cy, cx + 13 * u, cy, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, 2 * u, p)
            }
            Glyph.REGION -> {
                p.style = Paint.Style.STROKE
                p.pathEffect = DashPathEffect(floatArrayOf(5 * u, 4 * u), 0f)
                c.drawRect(cx - 10 * u, cy - 8 * u, cx + 10 * u, cy + 8 * u, p)
                p.pathEffect = null
            }
            Glyph.EYE -> {
                p.style = Paint.Style.STROKE
                c.drawOval(RectF(cx - 11 * u, cy - 6 * u, cx + 11 * u, cy + 6 * u), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, 3 * u, p)
            }
            Glyph.CAMERA -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(cx - 10 * u, cy - 6 * u, cx + 10 * u, cy + 8 * u, 2 * u, 2 * u, p)
                c.drawCircle(cx, cy + 1 * u, 4 * u, p)
                c.drawLine(cx - 4 * u, cy - 8 * u, cx + 4 * u, cy - 8 * u, p)
            }
        }
    }
}

/**
 * Контейнер, который можно перетаскивать за любое место. Кнопки внутри по-прежнему
 * нажимаются: перехват начинается только после выхода за порог касания.
 */
class DragFrameLayout(
    context: Context,
    private val onDrag: (dx: Int, dy: Int) -> Unit,
    private val onEnd: () -> Unit
) : FrameLayout(context) {

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                lastX = downX
                lastY = downY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    dragging = true
                    lastX = downX
                    lastY = downY
                    return true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    val dx = (e.rawX - lastX).toInt()
                    val dy = (e.rawY - lastY).toInt()
                    if (dx != 0 || dy != 0) {
                        lastX += dx
                        lastY += dy
                        onDrag(dx, dy)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) onEnd()
                dragging = false
            }
        }
        return true
    }
}

/**
 * Рамка области наблюдения. Окно больше области на [margin] с каждой стороны:
 * контур и маркеры рисуются СНАРУЖИ области, поэтому пиксели внутри области
 * (которые анализирует детектор) рамка не искажает. Рамка найденного объекта
 * тоже рисуется с отступом от объекта.
 */
class RegionOverlayView(
    context: Context,
    private val margin: Int,
    private val listener: Listener
) : View(context) {

    interface Listener {
        fun onMove(dx: Int, dy: Int)
        fun onResize(handle: RegionHandle, dx: Int, dy: Int)
    }

    private enum class Grab { NONE, BODY, TL, TR, BL, BR }

    var editMode: Boolean = false
        set(value) {
            field = value
            invalidate()
        }
    var showFrame: Boolean = true
        set(value) {
            field = value
            invalidate()
        }
    var frameColor: Int = 0xFF00E5FF.toInt()
        set(value) {
            field = value
            invalidate()
        }
    var frameAlpha: Float = 0.9f
        set(value) {
            field = value
            invalidate()
        }
    var detection: RectF? = null
        set(value) {
            field = value
            invalidate()
        }
    var detectionScore: Float = 0f

    private val d = resources.displayMetrics.density
    private val stroke = 3f * d
    private val handleR = 10f * d
    private val handleOff = 12f * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E676.toInt()
        textSize = 13f * d
        isFakeBoldText = true
    }

    private var grab = Grab.NONE
    private var lastX = 0f
    private var lastY = 0f

    override fun onDraw(c: Canvas) {
        val l = margin.toFloat()
        val t = margin.toFloat()
        val r = (width - margin).toFloat()
        val b = (height - margin).toFloat()
        val rgb = frameColor and 0x00FFFFFF

        if (showFrame || editMode) {
            if (editMode) {
                paint.style = Paint.Style.FILL
                paint.color = rgb or (0x22 shl 24)
                c.drawRect(l, t, r, b, paint)
            }
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = stroke
            paint.color = rgb or ((frameAlpha.coerceIn(0.05f, 1f) * 255).toInt() shl 24)
            val o = stroke / 2f
            c.drawRect(l - o, t - o, r + o, b + o, paint) // контур целиком снаружи области

            if (editMode) {
                paint.style = Paint.Style.FILL
                c.drawCircle(l - handleOff, t - handleOff, handleR, paint)
                c.drawCircle(r + handleOff, t - handleOff, handleR, paint)
                c.drawCircle(l - handleOff, b + handleOff, handleR, paint)
                c.drawCircle(r + handleOff, b + handleOff, handleR, paint)
            }
        }

        detection?.let { dr ->
            val g = 4f * d
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = 0xFF00E676.toInt()
            c.drawRect(dr.left - g, dr.top - g, dr.right + g, dr.bottom + g, paint)
            val label = "${(detectionScore * 100).toInt()}%"
            val ty = if (dr.top - g - 6 * d > 14 * d) dr.top - g - 6 * d else dr.bottom + g + 16 * d
            c.drawText(label, dr.left - g, ty, textPaint)
        }
    }

    private fun hit(x: Float, y: Float): Grab {
        val l = margin.toFloat()
        val t = margin.toFloat()
        val r = (width - margin).toFloat()
        val b = (height - margin).toFloat()
        val rad = 26f * d
        fun near(cx: Float, cy: Float): Boolean = (x - cx) * (x - cx) + (y - cy) * (y - cy) <= rad * rad
        return when {
            near(l - handleOff, t - handleOff) -> Grab.TL
            near(r + handleOff, t - handleOff) -> Grab.TR
            near(l - handleOff, b + handleOff) -> Grab.BL
            near(r + handleOff, b + handleOff) -> Grab.BR
            x in l..r && y in t..b -> Grab.BODY
            else -> Grab.NONE
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editMode) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                grab = hit(e.x, e.y)
                if (grab == Grab.NONE) return false
                lastX = e.rawX
                lastY = e.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (grab == Grab.NONE) return false
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    lastX += dx
                    lastY += dy
                    when (grab) {
                        Grab.BODY -> listener.onMove(dx, dy)
                        Grab.TL -> listener.onResize(RegionHandle.TL, dx, dy)
                        Grab.TR -> listener.onResize(RegionHandle.TR, dx, dy)
                        Grab.BL -> listener.onResize(RegionHandle.BL, dx, dy)
                        Grab.BR -> listener.onResize(RegionHandle.BR, dx, dy)
                        Grab.NONE -> {}
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                grab = Grab.NONE
                return true
            }
        }
        return true
    }
}

/** Маркер кликера: кольцо с перекрестием, центр = точка нажатия. */
class MarkerView(context: Context, private val listener: Listener) : View(context) {

    interface Listener {
        fun onDrag(dx: Int, dy: Int)
        fun onDragEnd()
    }

    var unlocked: Boolean = false
        set(value) {
            field = value
            invalidate()
        }
    var accent: Int = Color.WHITE
        set(value) {
            field = value
            invalidate()
        }
    /** Режим «точка в центре»: только маленькая метка, без кольца и перекрестия. */
    var dotOnly: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastX = 0f
    private var lastY = 0f

    override fun onDraw(c: Canvas) {
        if (dotOnly) {
            val dx = width / 2f
            val dy = height / 2f
            paint.style = Paint.Style.FILL
            paint.color = 0xAA000000.toInt()
            c.drawCircle(dx, dy, 6f * d, paint)
            paint.color = accent
            c.drawCircle(dx, dy, 4f * d, paint)
            return
        }

        val cx = width / 2f
        val cy = height / 2f
        val r = 16f * d

        // тёмная обводка для контраста на любом фоне
        paint.style = Paint.Style.STROKE
        paint.color = 0xAA000000.toInt()
        paint.strokeWidth = 5f * d
        c.drawCircle(cx, cy, r, paint)
        paint.strokeCap = Paint.Cap.ROUND
        drawTicks(c, cx, cy, r)

        paint.color = accent
        paint.strokeWidth = 2.5f * d
        c.drawCircle(cx, cy, r, paint)
        drawTicks(c, cx, cy, r)

        paint.style = Paint.Style.FILL
        c.drawCircle(cx, cy, 2f * d, paint)

        if (unlocked) { // режим перемещения: пунктирное внешнее кольцо
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * d
            paint.pathEffect = DashPathEffect(floatArrayOf(6 * d, 5 * d), 0f)
            c.drawCircle(cx, cy, r + 12f * d, paint)
            paint.pathEffect = null
        }
    }

    private fun drawTicks(c: Canvas, cx: Float, cy: Float, r: Float) {
        val a = r + 2f * d
        val b = r + 9f * d
        c.drawLine(cx, cy - a, cx, cy - b, paint)
        c.drawLine(cx, cy + a, cx, cy + b, paint)
        c.drawLine(cx - a, cy, cx - b, cy, paint)
        c.drawLine(cx + a, cy, cx + b, cy, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!unlocked) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    lastX += dx
                    lastY += dy
                    listener.onDrag(dx, dy)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                listener.onDragEnd()
                return true
            }
        }
        return true
    }
}
