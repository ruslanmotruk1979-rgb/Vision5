package com.visionclicker.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VcDark = darkColorScheme(
    primary = Color(0xFF4DD0E1),
    onPrimary = Color(0xFF00363D),
    secondary = Color(0xFF80CBC4),
    tertiary = Color(0xFFFFB74D),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE6E8EE),
    surface = Color(0xFF171A21),
    onSurface = Color(0xFFE6E8EE),
    surfaceVariant = Color(0xFF222733),
    onSurfaceVariant = Color(0xFFB4BAC8),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF3B0000),
    outline = Color(0xFF3A4152)
)

object VcColors {
    val ok = Color(0xFF00E676)
    val warn = Color(0xFFFFB74D)
    val bad = Color(0xFFFF6B6B)
    val idle = Color(0xFF8A93A6)
    val run = Color(0xFF4DD0E1)
}

@Composable
fun VisionClickerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = VcDark, content = content)
}
