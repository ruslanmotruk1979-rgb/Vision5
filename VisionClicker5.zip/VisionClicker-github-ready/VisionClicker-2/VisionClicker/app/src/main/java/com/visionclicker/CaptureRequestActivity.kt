package com.visionclicker

import android.content.Context
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.visionclicker.model.AppRuntime
import com.visionclicker.service.MonitoringService

/**
 * Невидимая активность: показывает системный диалог согласия на захват экрана
 * и после согласия запускает MonitoringService. Нужна, потому что запрос
 * согласия можно показать только из активности (в том числе по кнопке с плавающей панели).
 */
class CaptureRequestActivity : ComponentActivity() {

    companion object {
        const val EXTRA_SNAPSHOT = "snapshot"
    }

    private var snapshot = false

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            MonitoringService.start(this, res.resultCode, data, snapshot)
        } else {
            Toast.makeText(this, "Доступ к захвату экрана не предоставлен", Toast.LENGTH_LONG).show()
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        snapshot = intent.getBooleanExtra(EXTRA_SNAPSHOT, false)
        if (savedInstanceState != null) return

        if (!snapshot && AppRuntime.state.value.isRunning) { // уже работает
            finish()
            return
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val request = if (Build.VERSION.SDK_INT >= 34) {
            // Android 14+: только «весь экран» — иначе пользователь может выбрать одно приложение,
            // и поверх других приложений захват не заработает
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        launcher.launch(request)
    }
}
