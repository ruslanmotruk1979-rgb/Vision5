package com.visionclicker.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.visionclicker.CaptureRequestActivity
import com.visionclicker.MainActivity
import com.visionclicker.container
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.Command
import com.visionclicker.service.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import android.view.WindowManager

/**
 * Плавающие элементы поверх других приложений (SYSTEM_ALERT_WINDOW):
 * панель управления, рамка области наблюдения, маркер кликера.
 */
class FloatingOverlayService : Service() {

    companion object {
        const val ACTION_SHOW_PANEL = "com.visionclicker.overlay.SHOW_PANEL"
        const val ACTION_CLOSE = "com.visionclicker.overlay.CLOSE"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingOverlayService::class.java))
        }

        fun close(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingOverlayService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var wm: WindowManager
    private lateinit var cal: OverlayCalibrator
    private lateinit var region: RegionOverlay
    private lateinit var marker: MarkerOverlay
    private lateinit var panel: PanelOverlay
    private var initialized = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!enterForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Нет разрешения «Поверх других приложений»", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_CLOSE) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!initialized) setup()
        AppRuntime.panelHidden.value = false // старт и ACTION_SHOW_PANEL показывают панель
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (initialized) {
            region.remove()
            marker.remove()
            panel.hide()
        }
        scope.cancel()
        AppRuntime.overlayRunning.value = false
        AppRuntime.regionEditing.value = false
        AppRuntime.markerUnlocked.value = false
        super.onDestroy()
    }

    private fun enterForeground(): Boolean = try {
        val n = Notifications.overlay(this)
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this, Notifications.ID_OVERLAY, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(Notifications.ID_OVERLAY, n)
        }
        true
    } catch (e: Exception) {
        false
    }

    private fun setup() {
        initialized = true
        val c = container
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cal = OverlayCalibrator(this, wm)
        region = RegionOverlay(this, wm, c.settings, c.regions, cal)
        marker = MarkerOverlay(this, wm, c.settings, cal)
        panel = PanelOverlay(this, wm, c.settings, panelActions)
        AppRuntime.overlayRunning.value = true

        scope.launch { c.settings.settings.collect { refreshAll() } }
        scope.launch { c.regions.region.collect { region.refresh() } }
        scope.launch {
            AppRuntime.screen.collect {
                cal.measure { refreshAll() }
                refreshAll()
            }
        }
        scope.launch { AppRuntime.detection.collect { region.setDetection(it) } }
        scope.launch {
            AppRuntime.regionEditing.collect {
                region.setEditing(it)
                panel.update()
            }
        }
        scope.launch {
            AppRuntime.markerUnlocked.collect {
                marker.refresh()
                panel.update()
            }
        }
        scope.launch {
            // На время снимка-шаблона прячем все элементы, чтобы они не попали в кадр
            AppRuntime.snapshotInProgress.collect { hide ->
                region.setHidden(hide)
                marker.setHidden(hide)
                if (hide) panel.hide() else if (!AppRuntime.panelHidden.value) panel.show()
            }
        }
        scope.launch {
            combine(
                AppRuntime.state, AppRuntime.paused, AppRuntime.objectPresent, AppRuntime.clicking
            ) { _, _, _, _ -> Unit }.collect {
                panel.update()
                marker.refresh()
            }
        }
        scope.launch {
            AppRuntime.panelHidden.collect { hidden ->
                if (hidden) panel.hide() else if (!AppRuntime.snapshotInProgress.value) panel.show()
            }
        }
    }

    private fun refreshAll() {
        region.refresh()
        marker.refresh()
        panel.update()
    }

    private fun launchCapture(snapshot: Boolean) {
        try {
            startActivity(
                Intent(this, CaptureRequestActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(CaptureRequestActivity.EXTRA_SNAPSHOT, snapshot)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть запрос захвата. Запустите из приложения.", Toast.LENGTH_LONG).show()
        }
    }

    private val panelActions = object : PanelOverlay.Actions {
        override fun onPlay() {
            val st = AppRuntime.state.value
            if (st.isRunning && AppRuntime.paused.value) {
                AppRuntime.commands.tryEmit(Command.RESUME)
            } else if (!st.isRunning) {
                launchCapture(snapshot = false)
            }
        }

        override fun onPause() {
            AppRuntime.commands.tryEmit(Command.PAUSE)
        }

        override fun onStop() {
            AppRuntime.commands.tryEmit(Command.EMERGENCY_STOP)
        }

        override fun onSettings() {
            try {
                startActivity(
                    Intent(this@FloatingOverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (_: Exception) {
            }
        }

        override fun onHide() {
            AppRuntime.panelHidden.value = true
            Toast.makeText(
                this@FloatingOverlayService,
                "Панель скрыта. Вернуть: уведомление «Показать панель» или приложение.",
                Toast.LENGTH_LONG
            ).show()
        }

        override fun onToggleMarker() {
            AppRuntime.markerUnlocked.value = !AppRuntime.markerUnlocked.value
        }

        override fun onToggleRegion() {
            val c = container
            if (AppRuntime.regionEditing.value) {
                c.regions.commit() // подтвердить и сохранить координаты
                AppRuntime.regionEditing.value = false
            } else if (!c.settings.current.fullScreen) {
                AppRuntime.regionEditing.value = true
            } else {
                Toast.makeText(
                    this@FloatingOverlayService,
                    "В режиме «весь экран» область не редактируется",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        override fun onToggleFrame() {
            container.settings.update { it.copy(frameVisible = !it.frameVisible) }
        }

        override fun onSnapshot() {
            launchCapture(snapshot = true)
        }
    }
}
