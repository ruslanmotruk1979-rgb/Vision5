package com.visionclicker.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import kotlin.math.abs

object OverlayParams {

    /**
     * Параметры окна-оверлея в абсолютных координатах экрана.
     * [alpha] ≤ 0.8 нужен для «сквозных» окон: Android 12+ блокирует касания, проходящие
     * сквозь почти непрозрачное окно другого приложения (в т.ч. жесты нашей же службы).
     */
    fun make(w: Int, h: Int, x: Int, y: Int, touchable: Boolean, alpha: Float = 1f): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        p.alpha = alpha
        p.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    fun isTouchable(p: WindowManager.LayoutParams): Boolean =
        (p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0

    fun setTouchable(p: WindowManager.LayoutParams, touchable: Boolean) {
        p.flags = if (touchable) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
    }
}

/**
 * Измеряет смещение между координатами окна-оверлея и реальными координатами экрана
 * (на некоторых устройствах система сдвигает окна на высоту строки состояния/выреза).
 * Без этой поправки рамка области и маркер визуально не совпадали бы с тем, что видит захват и жест.
 * Для «нормальных» устройств смещение равно 0.
 */
class OverlayCalibrator(private val ctx: Context, private val wm: WindowManager) {

    var offX: Int = 0
        private set
    var offY: Int = 0
        private set

    fun measure(onDone: () -> Unit) {
        val probe = View(ctx)
        val p = OverlayParams.make(1, 1, 0, 0, touchable = false, alpha = 0.01f)
        try {
            wm.addView(probe, p)
        } catch (e: Exception) {
            onDone()
            return
        }

        val handler = Handler(Looper.getMainLooper())
        var finished = false
        fun finish() {
            if (finished) return
            finished = true
            try {
                wm.removeView(probe)
            } catch (_: Exception) {
            }
            onDone()
        }

        probe.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (probe.viewTreeObserver.isAlive) probe.viewTreeObserver.removeOnGlobalLayoutListener(this)
                val loc = IntArray(2)
                probe.getLocationOnScreen(loc)
                if (abs(loc[0]) < 300 && abs(loc[1]) < 300) {
                    offX = loc[0]
                    offY = loc[1]
                }
                finish()
            }
        })
        handler.postDelayed({ finish() }, 1500)
    }
}
