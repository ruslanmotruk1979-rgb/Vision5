package com.visionclicker.service

import android.app.Activity
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.visionclicker.MainActivity
import com.visionclicker.capture.ScreenCaptureManager
import com.visionclicker.click.AutomationAccessibilityService
import com.visionclicker.click.ClickController
import com.visionclicker.container
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.AppSettings
import com.visionclicker.model.Command
import com.visionclicker.model.DetectionInfo
import com.visionclicker.model.MatchMode
import com.visionclicker.model.MonitoringState
import com.visionclicker.model.PerformanceMode
import com.visionclicker.model.PxRect
import com.visionclicker.vision.TemplateMatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.opencv.core.Mat
import kotlin.math.roundToInt

/**
 * Управляет циклом наблюдения (конечный автомат STOPPED → WAITING → DETECTED → CLICKING / ERROR).
 * Сам не захватывает экран, не ищет шаблон и не кликает — только координирует
 * [ScreenCaptureManager], [TemplateMatcher] и [ClickController].
 *
 * Работает как foreground-сервис типа mediaProjection с постоянным уведомлением.
 */
class MonitoringService : Service() {

    companion object {
        const val ACTION_START = "com.visionclicker.action.START"
        const val ACTION_SNAPSHOT = "com.visionclicker.action.SNAPSHOT"
        const val ACTION_STOP = "com.visionclicker.action.STOP"
        const val ACTION_TOGGLE_PAUSE = "com.visionclicker.action.TOGGLE_PAUSE"

        /** Минимальный запас вокруг объекта, в пикселях. */
        private const val TRACK_MIN_PAD_PX = 8
        private const val EXTRA_CODE = "result_code"
        private const val EXTRA_DATA = "result_data"

        fun start(ctx: Context, resultCode: Int, data: Intent, snapshot: Boolean) {
            val i = Intent(ctx, MonitoringService::class.java)
                .setAction(if (snapshot) ACTION_SNAPSHOT else ACTION_START)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private data class AnalysisKey(
        val region: PxRect,
        val templateVersion: Int,
        val threshold: Float,
        val mode: MatchMode,
        val minSize: Int,
        val performance: PerformanceMode
    )

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var capture: ScreenCaptureManager? = null
    private var clicker: ClickController? = null
    private var loopJob: Job? = null

    @Volatile
    private var running = false

    @Volatile
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // Команды обрабатываются на главном потоке — они не зависят от нагрузки анализа.
        scope.launch(Dispatchers.Main.immediate) {
            AppRuntime.commands.collect { handle(it) }
        }
        scope.launch(Dispatchers.Main.immediate) {
            combine(AppRuntime.state, AppRuntime.paused) { s, p -> s to p }.collect { (s, p) ->
                if (running && !stopping) notifyForeground(s, p)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        // startForeground нужно вызвать сразу и ДО getMediaProjection (требование Android 14+)
        if (!enterForeground()) {
            if (action == ACTION_START || action == ACTION_SNAPSHOT) {
                AppRuntime.errorMessage.value = "Не удалось запустить службу захвата экрана"
                AppRuntime.state.value = MonitoringState.ERROR
            }
            stopSelf()
            return START_NOT_STICKY
        }
        when (action) {
            ACTION_START -> begin(intent, snapshot = false)
            ACTION_SNAPSHOT -> begin(intent, snapshot = true)
            ACTION_TOGGLE_PAUSE -> handle(Command.TOGGLE_PAUSE)
            else -> if (running) stopMonitoring()
        }
        if (!running && !stopping) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (running) { // убиты системой при активной работе
            running = false
            stopping = true
            clicker?.stop()
            capture?.release()
            AppRuntime.objectPresent.value = false
            AppRuntime.detection.value = null
            AppRuntime.clicking.value = false
            AppRuntime.snapshotInProgress.value = false
            if (AppRuntime.state.value != MonitoringState.ERROR) AppRuntime.state.value = MonitoringState.STOPPED
        }
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ запуск

    private fun enterForeground(): Boolean = try {
        ServiceCompat.startForeground(
            this,
            Notifications.ID_MONITOR,
            Notifications.monitoring(this, AppRuntime.state.value, AppRuntime.paused.value),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        true
    } catch (e: Exception) {
        false
    }

    private fun begin(intent: Intent?, snapshot: Boolean) {
        if (running) return
        stopping = false
        running = true

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null || code != Activity.RESULT_OK) {
            failWith("Нет согласия на захват экрана")
            return
        }
        if (!AppRuntime.openCvReady) {
            failWith("Не удалось загрузить библиотеку OpenCV")
            return
        }

        val repo = container.settings
        if (!snapshot) {
            if (!repo.hasEnabledTemplate()) {
                failWith("Не выбран шаблон объекта (вкладка «Шаблон»)")
                return
            }
            val problem = permissionProblem(repo.current, atStart = true)
            if (problem != null) {
                failWith(problem)
                return
            }
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (mp == null) {
            failWith("Система отклонила захват экрана")
            return
        }

        val cap = ScreenCaptureManager(applicationContext)
        capture = cap
        try {
            cap.start(mp) {
                main.post { failWith("Захват экрана остановлен системой или пользователем") }
            }
        } catch (e: Exception) {
            failWith("Не удалось начать захват экрана: ${e.message}")
            return
        }

        AppRuntime.errorMessage.value = null
        AppRuntime.clickCount.value = 0L
        AppRuntime.paused.value = false
        AppRuntime.matcherNote.value = null

        if (snapshot) {
            runSnapshot(cap)
            return
        }

        val clk = ClickController(scope, repo) { msg -> main.post { failWith(msg) } }
        clicker = clk
        clk.start()
        AppRuntime.state.value = MonitoringState.WAITING

        // Производное состояние: объект найден / идут клики
        scope.launch(Dispatchers.Main.immediate) {
            combine(AppRuntime.objectPresent, AppRuntime.clicking) { p, c -> p to c }.collect { (p, c) ->
                if (running && !stopping) {
                    AppRuntime.state.value = when {
                        p && c -> MonitoringState.CLICKING
                        p -> MonitoringState.DETECTED
                        else -> MonitoringState.WAITING
                    }
                }
            }
        }

        loopJob = scope.launch { analysisLoop(cap, clk) }
    }

    // ------------------------------------------------------------------ главный цикл

    private suspend fun analysisLoop(cap: ScreenCaptureManager, clk: ClickController) {
        val repo = container.settings
        val regions = container.regions
        val regionMat = Mat()
        val matchers = ArrayList<TemplateMatcher>()
        var tplVersion = -1
        var lastKey: AnalysisKey? = null
        var pos = 0
        var neg = 0
        var present = false
        var nextWatch = 0L
        var problemSince = 0L
        // Последнее известное положение объекта (координаты экрана) и флаг «выпал из окна»
        var lastObj: PxRect? = null
        var lostLast = false

        try {
            while (currentCoroutineContext().isActive) {
                val t0 = SystemClock.elapsedRealtime()
                val s = repo.current

                // Сторож разрешений: при потере — аварийная остановка
                if (t0 >= nextWatch) {
                    nextWatch = t0 + 500
                    val problem = permissionProblem(s, atStart = false)
                    if (problem == null) {
                        problemSince = 0L
                    } else {
                        if (problemSince == 0L) problemSince = t0
                        if (t0 - problemSince > 1500) {
                            main.post { failWith(problem) }
                            return
                        }
                    }
                }

                // Пауза: захват жив (повторное согласие не нужно), анализ и клики остановлены
                if (AppRuntime.paused.value) {
                    if (present) {
                        present = false
                        setPresent(false, clk)
                    }
                    pos = 0
                    neg = 0
                    lastObj = null
                    lostLast = false
                    lastKey = null
                    delay(100)
                    continue
                }

                cap.resizeIfNeeded(AppRuntime.screen.value)
                val newFrame = cap.acquire()

                val tv = repo.templateVersion.value
                if (tv != tplVersion) {
                    matchers.forEach { it.release() }
                    matchers.clear()
                    for (t in repo.enabledTemplates()) {
                        val m = TemplateMatcher()
                        m.setTemplate(repo.loadTemplate(t.id))
                        matchers.add(m)
                    }
                    tplVersion = tv
                    lastObj = null
                    lostLast = false
                    lastKey = null
                }

                // Анализируемая область:
                //  - объект ещё не найден — заданная пользователем зона;
                //  - объект найден — окно вокруг него, которое едет вместе с ним;
                //  - объект выпал из окна — поиск по всему экрану, зона пользователя не ограничивает.
                val zone = regions.effective()
                val screenRect = PxRect(0, 0, AppRuntime.screen.value.width, AppRuntime.screen.value.height)
                val lo = lastObj
                val region = when {
                    s.centerDot -> screenRect // объект должен накрыть центр — ищем по всему экрану
                    !s.trackObject || lo == null -> zone
                    lostLast -> screenRect
                    else -> trackingZone(lo, screenRect, s.trackMarginPct)
                }
                AppRuntime.trackingWide.value = !s.centerDot && s.trackObject && lo != null && lostLast
                val key = AnalysisKey(region, tv, s.threshold, s.matchMode, s.minObjectSizePx, s.performance)

                // На статичном экране кадров нет — не тратим CPU, если ничего не изменилось
                if ((newFrame || key != lastKey) && cap.copyRegion(region, regionMat)) {
                    val t1 = SystemClock.elapsedRealtime()
                    val res = matchAny(matchers, regionMat, s)
                    AppRuntime.analysisMs.value = SystemClock.elapsedRealtime() - t1
                    AppRuntime.lastScore.value = res.score
                    AppRuntime.matcherNote.value = res.note
                    lastKey = key

                    val r = res.rect
                    val obj = if (res.found && r != null) PxRect(
                        region.left + r.left, region.top + r.top,
                        region.left + r.right, region.top + r.bottom
                    ) else null

                    if (s.centerDot) {
                        // Точка в центре: объект должен накрыть центр экрана. Без подтверждений — сразу.
                        val scr = AppRuntime.screen.value
                        val covers = obj != null && obj.contains(scr.width / 2, scr.height / 2)
                        if (covers != present) {
                            present = covers
                            setPresent(covers, clk)
                        }
                    } else {
                        // Защита от ложных срабатываний: подтверждение N кадров, потеря — M кадров
                        if (res.found) {
                            pos++
                            neg = 0
                        } else {
                            pos = 0
                            neg++
                        }
                        if (!present && pos >= s.confirmFrames) {
                            present = true
                            setPresent(true, clk)
                        } else if (present && neg >= s.lossFrames) {
                            present = false
                            setPresent(false, clk)
                        }
                    }

                    if (present && obj != null) {
                        AppRuntime.detection.value = DetectionInfo(obj, res.score)
                    }
                    if (s.trackObject) {
                        if (obj != null) {
                            lastObj = obj
                            lostLast = false
                        } else if (lastObj != null) {
                            lostLast = true // в окне не нашли — со следующего кадра ищем по всему экрану
                        }
                    }
                }

                val spent = SystemClock.elapsedRealtime() - t0
                delay(maxOf(1L, s.checkIntervalMs - spent))
            }
        } finally {
            regionMat.release()
            matchers.forEach { it.release() }
        }
    }

    /**
     * Окно слежения: найденный объект плюс запас со всех сторон (доля от большей стороны объекта),
     * чтобы он мог сдвинуться между кадрами. Ограничено границами экрана.
     */
    private fun trackingZone(obj: PxRect, bounds: PxRect, marginFrac: Float): PxRect {
        val pad = maxOf(TRACK_MIN_PAD_PX, (maxOf(obj.width, obj.height) * marginFrac).roundToInt())
        val l = maxOf(bounds.left, obj.left - pad)
        val t = maxOf(bounds.top, obj.top - pad)
        val r = minOf(bounds.right, obj.right + pad)
        val b = minOf(bounds.bottom, obj.bottom + pad)
        // окно не вмещает объект целиком — ищем по всему экрану
        return if (r - l >= obj.width && b - t >= obj.height) PxRect(l, t, r, b) else bounds
    }

    /**
     * Ищет все включённые шаблоны. Первое совпадение выше порога сразу побеждает
     * (объект виден — дальнейший поиск не нужен). Иначе возвращается лучший результат.
     */
    private fun matchAny(matchers: List<TemplateMatcher>, region: Mat, s: AppSettings): TemplateMatcher.Result {
        val p = TemplateMatcher.Params(s.matchMode, s.threshold, s.minObjectSizePx, s.performance.scale)
        var best: TemplateMatcher.Result? = null
        for (m in matchers) {
            val r = m.match(region, p)
            if (r.found) return r
            if (best == null || r.score > best.score) best = r
        }
        return best ?: TemplateMatcher.Result(false, 0f, null, "Нет включённых шаблонов")
    }

    private fun setPresent(v: Boolean, clk: ClickController) {
        AppRuntime.objectPresent.value = v
        if (!v) AppRuntime.detection.value = null
        clk.setPresent(v) // при false клики отменяются немедленно
    }

    private fun permissionProblem(s: AppSettings, atStart: Boolean): String? {
        if (!Settings.canDrawOverlays(this)) return "Отозвано разрешение «Поверх других приложений»"
        if (s.clickerEnabled) {
            val ok = if (atStart) {
                AutomationAccessibilityService.isEnabled(this)
            } else {
                AutomationAccessibilityService.instance != null
            }
            if (!ok) return "Служба специальных возможностей выключена — нажатия невозможны"
        }
        return null
    }

    // ------------------------------------------------------------------ снимок для шаблона

    private fun runSnapshot(cap: ScreenCaptureManager) {
        loopJob = scope.launch {
            toast("Снимок через 5 секунд — откройте нужный экран")
            delay(4300)
            AppRuntime.snapshotInProgress.value = true // оверлеи прячутся, чтобы не попасть в кадр
            delay(700)

            var bmp: Bitmap? = null
            var attempts = 0
            while (bmp == null && attempts < 15) {
                cap.acquire()
                bmp = cap.grabFullBitmap()
                if (bmp == null) delay(200)
                attempts++
            }
            AppRuntime.snapshotInProgress.value = false

            if (bmp != null) {
                container.settings.saveScreenshot(bmp)
                AppRuntime.pendingScreenshot.value = true
                main.post { openApp() }
            } else {
                toast("Не удалось получить кадр экрана")
            }
            delay(300)
            main.post { stopMonitoring() }
        }
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        try {
            startActivity(i)
        } catch (_: Exception) {
        }
        Notifications.snapshotReady(this)
    }

    // ------------------------------------------------------------------ команды и остановка

    private fun handle(cmd: Command) {
        if (!running || stopping) return
        when (cmd) {
            Command.STOP, Command.EMERGENCY_STOP -> stopMonitoring()
            Command.PAUSE -> AppRuntime.paused.value = true
            Command.RESUME -> AppRuntime.paused.value = false
            Command.TOGGLE_PAUSE -> AppRuntime.paused.value = !AppRuntime.paused.value
        }
    }

    private fun failWith(message: String) {
        if (stopping) return
        stopMonitoring(message)
    }

    /** Полная остановка: отмена кликов и задач, освобождение захвата, снятие уведомления. */
    private fun stopMonitoring(error: String? = null) {
        if (stopping) return
        stopping = true
        running = false

        clicker?.stop()
        clicker = null
        loopJob?.cancel()
        loopJob = null
        capture?.release()
        capture = null

        AppRuntime.objectPresent.value = false
        AppRuntime.detection.value = null
        AppRuntime.clicking.value = false
        AppRuntime.paused.value = false
        AppRuntime.snapshotInProgress.value = false
        AppRuntime.trackingWide.value = false
        AppRuntime.errorMessage.value = error
        AppRuntime.state.value = if (error != null) MonitoringState.ERROR else MonitoringState.STOPPED

        if (error != null) Notifications.alert(this, "Vision Clicker остановлен", error)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyForeground(state: MonitoringState, paused: Boolean) {
        getSystemService(NotificationManager::class.java)
            .notify(Notifications.ID_MONITOR, Notifications.monitoring(this, state, paused))
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }
}
