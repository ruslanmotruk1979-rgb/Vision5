package com.visionclicker.util

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import com.visionclicker.model.ScreenSize

object ScreenMetrics {
    /** Реальный размер экрана (с учётом текущей ориентации), в пикселях. */
    fun real(context: Context): ScreenSize {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val density = context.resources.configuration.densityDpi
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            ScreenSize(b.width(), b.height(), density)
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            ScreenSize(dm.widthPixels, dm.heightPixels, density)
        }
    }
}

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density

fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density).toInt()
