package com.visionclicker.model

enum class MatchMode(val title: String, val hint: String) {
    EXACT("Точное совпадение", "Один масштаб, сравнение по цвету. Быстро и строго."),
    SCALED("Масштабируемый шаблон", "Серое изображение, масштабы 0.8–1.25. Терпимо к яркости и оттенку."),
    EDGES("Контуры", "Сравнение границ, масштабы 0.7–1.4. Устойчиво к цвету, свечению и бликам.")
}

enum class ClickMode(val title: String, val hint: String) {
    SINGLE("Одиночный клик", "Один клик при появлении объекта. Следующий — после исчезновения и нового появления."),
    CONTINUOUS("Непрерывные клики", "Клики с заданным интервалом, пока объект виден в области.")
}

enum class PerformanceMode(val title: String, val scale: Float, val hint: String) {
    ACCURACY("Точность", 1.0f, "Анализ в полном разрешении (больше нагрузка)"),
    BALANCED("Баланс", 0.75f, "Анализ в 75% разрешения"),
    SPEED("Скорость", 0.5f, "Анализ в 50% разрешения (мелкие объекты могут теряться)")
}

enum class RegionHandle { TL, TR, BL, BR }

data class ScreenSize(val width: Int, val height: Int, val densityDpi: Int) {
    val isLandscape: Boolean get() = width > height
}

/** Прямоугольник в пикселях экрана. */
data class PxRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top

    fun contains(x: Int, y: Int): Boolean = x >= left && x < right && y >= top && y < bottom
}

/** Прямоугольник в долях экрана (0..1) — переживает смену разрешения. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

data class NormPoint(val x: Float, val y: Float)

/** Один шаблон объекта. Изображение хранится в файле templates/<id>.png. */
data class TemplateItem(val id: String, val name: String, val enabled: Boolean)

data class AppSettings(
    // --- распознавание ---
    val threshold: Float = 0.85f,
    val matchMode: MatchMode = MatchMode.SCALED,
    val minObjectSizePx: Int = 12,
    val showDetectionBox: Boolean = true,
    val confirmFrames: Int = 1,
    val lossFrames: Int = 1,
    /** Вкладка «Слежение»: анализ идёт только вокруг объекта и едет за ним по всему экрану. */
    val trackObject: Boolean = true,
    /** Запас вокруг объекта в долях его размера. */
    val trackMarginPct: Float = 0.2f,

    // --- область наблюдения (отдельно для портрета и ландшафта) ---
    val fullScreen: Boolean = false,
    val regionPortrait: NormRect = NormRect(0.20f, 0.35f, 0.80f, 0.65f),
    val regionLandscape: NormRect = NormRect(0.30f, 0.25f, 0.70f, 0.75f),
    val frameVisible: Boolean = true,
    val frameColor: Int = 0xFF00E5FF.toInt(),
    val frameAlpha: Float = 0.9f,

    // --- кликер ---
    val clickerEnabled: Boolean = true,
    val clickMode: ClickMode = ClickMode.CONTINUOUS,
    val clickIntervalMs: Int = 200,
    val tapDurationMs: Int = 30,
    val maxClicksPerAppearance: Int = 0, // 0 = без ограничения
    val clickerPortrait: NormPoint = NormPoint(0.5f, 0.5f),
    val clickerLandscape: NormPoint = NormPoint(0.5f, 0.5f),
    val markerVisible: Boolean = true,
    /** Точка в центре экрана: клик в центр, срабатывание когда объект накрыл центр. */
    val centerDot: Boolean = false,

    // --- мониторинг ---
    val checkIntervalMs: Int = 50,
    val performance: PerformanceMode = PerformanceMode.BALANCED,

    // --- плавающая панель ---
    val autoShowPanel: Boolean = true,
    val panelCollapsedOnStart: Boolean = false,
    val panelOpacity: Float = 1.0f,

    val warningAccepted: Boolean = false
) {
    fun regionFor(landscape: Boolean): NormRect = if (landscape) regionLandscape else regionPortrait
    fun withRegion(landscape: Boolean, r: NormRect): AppSettings =
        if (landscape) copy(regionLandscape = r) else copy(regionPortrait = r)

    fun clickerFor(landscape: Boolean): NormPoint = if (landscape) clickerLandscape else clickerPortrait
    fun withClicker(landscape: Boolean, p: NormPoint): AppSettings =
        if (landscape) copy(clickerLandscape = p) else copy(clickerPortrait = p)
}

object Limits {
    const val MIN_CLICK_INTERVAL_MS = 50
    const val MAX_CLICK_INTERVAL_MS = 60_000
    const val MIN_TAP_MS = 10
    const val MAX_TAP_MS = 500
    const val MIN_CHECK_MS = 20
    const val MAX_CHECK_MS = 1000
}
