package com.visionclicker.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.visionclicker.data.SettingsRepository
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.DetectionInfo
import com.visionclicker.model.MonitoringState
import com.visionclicker.model.NormPoint
import com.visionclicker.model.RegionHandle
import com.visionclicker.region.RegionManager
import com.visionclicker.util.dpi
import kotlin.math.roundToInt

private val C_OK = 0xFF00E676.toInt()
private val C_WARN = 0xFFFFB74D.toInt()
private val C_BAD = 0xFFFF6B6B.toInt()
private val C_IDLE = 0xFF8A93A6.toInt()
private val C_RUN = 0xFF4DD0E1.toInt()

/** Окно с рамкой области и рамкой найденного объекта. */
class RegionOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val repo: SettingsRepository,
    private val regions: RegionManager,
    private val cal: OverlayCalibrator
) {
    private val margin = ctx.dpi(28f)
    private var view: RegionOverlayView? = null
    private var params: WindowManager.LayoutParams? = null
    private var editing = false
    private var detection: DetectionInfo? = null
    private var hidden = false

    private val listener = object : RegionOverlayView.Listener {
        override fun onMove(dx: Int, dy: Int) {
            regions.move(dx, dy)
            refresh()
        }

        override fun onResize(handle: RegionHandle, dx: Int, dy: Int) {
            regions.resize(handle, dx, dy)
            refresh()
        }
    }

    fun setEditing(v: Boolean) {
        editing = v
        refresh()
    }

    fun setDetection(d: DetectionInfo?) {
        detection = d
        refresh()
    }

    fun setHidden(v: Boolean) {
        hidden = v
        refresh()
    }

    fun refresh() {
        val s = repo.current
        val edit = editing && !s.fullScreen
        val wantFrame = s.frameVisible && !s.fullScreen
        val det = if (s.showDetectionBox) detection else null
        val needed = !hidden && (wantFrame || det != null || edit)
        if (!needed) {
            remove()
            return
        }

        val r = regions.effective()
        val nx = r.left - margin - cal.offX
        val ny = r.top - margin - cal.offY
        val nw = r.width + 2 * margin
        val nh = r.height + 2 * margin

        val existing = view
        val v: RegionOverlayView
        if (existing == null) {
            v = RegionOverlayView(ctx, margin, listener)
            val p = OverlayParams.make(nw, nh, nx, ny, touchable = edit, alpha = 0.78f)
            try {
                wm.addView(v, p)
            } catch (e: Exception) {
                return
            }
            view = v
            params = p
        } else {
            v = existing
            val p = params ?: return
            var changed = false
            if (p.x != nx || p.y != ny || p.width != nw || p.height != nh) {
                p.x = nx
                p.y = ny
                p.width = nw
                p.height = nh
                changed = true
            }
            if (OverlayParams.isTouchable(p) != edit) {
                OverlayParams.setTouchable(p, edit)
                changed = true
            }
            if (changed) {
                try {
                    wm.updateViewLayout(v, p)
                } catch (_: Exception) {
                }
            }
        }

        v.editMode = edit
        v.showFrame = wantFrame
        v.frameColor = s.frameColor
        v.frameAlpha = s.frameAlpha
        if (det != null) {
            val rr = det.rect
            val ox = (r.left - margin).toFloat()
            val oy = (r.top - margin).toFloat()
            v.detectionScore = det.score
            v.detection = RectF(rr.left - ox, rr.top - oy, rr.right - ox, rr.bottom - oy)
        } else {
            v.detection = null
        }
    }

    fun remove() {
        view?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
        params = null
    }
}

/** Маркер точки нажатия. По умолчанию «сквозной»: жесты кликера проходят через него. */
class MarkerOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val repo: SettingsRepository,
    private val cal: OverlayCalibrator
) {
    private val size = ctx.dpi(64f)
    private val dotSize = ctx.dpi(14f)
    private var view: MarkerView? = null
    private var viewDot = false
    private var params: WindowManager.LayoutParams? = null
    private var hidden = false
    private var dragging = false

    private val listener = object : MarkerView.Listener {
        override fun onDrag(dx: Int, dy: Int) {
            val p = params ?: return
            val screen = AppRuntime.screen.value
            val half = size / 2
            p.x = (p.x + dx).coerceIn(-half - cal.offX, screen.width - half - cal.offX)
            p.y = (p.y + dy).coerceIn(-half - cal.offY, screen.height - half - cal.offY)
            dragging = true
            view?.let {
                try {
                    wm.updateViewLayout(it, p)
                } catch (_: Exception) {
                }
            }
        }

        override fun onDragEnd() {
            val p = params
            dragging = false
            if (p == null) return
            val screen = AppRuntime.screen.value
            val cx = p.x + cal.offX + size / 2
            val cy = p.y + cal.offY + size / 2
            val point = NormPoint(
                (cx / screen.width.toFloat()).coerceIn(0f, 1f),
                (cy / screen.height.toFloat()).coerceIn(0f, 1f)
            )
            repo.update { it.withClicker(screen.isLandscape, point) }
        }
    }

    fun setHidden(v: Boolean) {
        hidden = v
        refresh()
    }

    fun refresh() {
        val s = repo.current
        val dot = s.centerDot
        if (hidden || (!dot && !s.markerVisible)) {
            remove()
            return
        }
        if (view != null && viewDot != dot) remove() // кольцо ↔ точка: пересоздаём окно нужного размера
        viewDot = dot
        val screen = AppRuntime.screen.value
        val sz = if (dot) dotSize else size
        val cx: Int
        val cy: Int
        if (dot) {
            cx = screen.width / 2
            cy = screen.height / 2
        } else {
            val pt = s.clickerFor(screen.isLandscape)
            cx = (pt.x * screen.width).roundToInt()
            cy = (pt.y * screen.height).roundToInt()
        }
        val nx = cx - sz / 2 - cal.offX
        val ny = cy - sz / 2 - cal.offY
        val unlocked = !dot && AppRuntime.markerUnlocked.value
        val accent = when {
            AppRuntime.clicking.value -> C_WARN
            AppRuntime.objectPresent.value -> C_OK
            AppRuntime.state.value.isRunning -> C_RUN
            else -> Color.WHITE
        }

        val existing = view
        val v: MarkerView
        if (existing == null) {
            v = MarkerView(ctx, listener)
            val p = OverlayParams.make(sz, sz, nx, ny, touchable = unlocked, alpha = 0.78f)
            try {
                wm.addView(v, p)
            } catch (e: Exception) {
                return
            }
            view = v
            params = p
        } else {
            v = existing
            val p = params ?: return
            var changed = false
            if (!dragging && (p.x != nx || p.y != ny)) {
                p.x = nx
                p.y = ny
                changed = true
            }
            if (OverlayParams.isTouchable(p) != unlocked) {
                OverlayParams.setTouchable(p, unlocked)
                changed = true
            }
            if (changed) {
                try {
                    wm.updateViewLayout(v, p)
                } catch (_: Exception) {
                }
            }
        }
        v.unlocked = unlocked
        v.dotOnly = dot
        v.accent = accent
    }

    fun remove() {
        view?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
        params = null
        dragging = false
    }
}

/** Компактная плавающая панель управления (сворачивается в маленькую кнопку). */
class PanelOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val repo: SettingsRepository,
    private val actions: Actions
) {
    interface Actions {
        fun onPlay()
        fun onPause()
        fun onStop()
        fun onSettings()
        fun onHide()
        fun onToggleMarker()
        fun onToggleRegion()
        fun onToggleFrame()
        fun onSnapshot()
    }

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * d).toInt()

    private var root: DragFrameLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var collapsed = repo.current.panelCollapsedOnStart

    private lateinit var expanded: LinearLayout
    private lateinit var mini: GlyphButton
    private lateinit var tvState: TextView
    private lateinit var tvObj: TextView
    private lateinit var tvClick: TextView
    private lateinit var bPlay: GlyphButton
    private lateinit var bPause: GlyphButton
    private lateinit var bStop: GlyphButton
    private lateinit var bMarker: GlyphButton
    private lateinit var bRegion: GlyphButton
    private lateinit var bFrame: GlyphButton

    fun show() {
        if (root != null) return
        build()
        update()
    }

    fun hide() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        params = null
    }

    fun update() {
        val r = root ?: return
        val st = AppRuntime.state.value
        val paused = AppRuntime.paused.value
        val running = st.isRunning

        bPlay.isEnabled = !running || paused
        bPause.isEnabled = running && !paused
        bStop.isEnabled = running
        bMarker.isActivated = AppRuntime.markerUnlocked.value
        bRegion.isActivated = AppRuntime.regionEditing.value
        bFrame.isActivated = repo.current.frameVisible

        val stateColor = when {
            st == MonitoringState.ERROR -> C_BAD
            running && paused -> C_WARN
            running -> C_RUN
            else -> C_IDLE
        }
        setIndicator(tvState, if (running && paused) "Пауза" else st.shortTitle, stateColor)
        setIndicator(tvObj, "Объект", if (AppRuntime.objectPresent.value) C_OK else C_IDLE)
        setIndicator(tvClick, "Клик", if (AppRuntime.clicking.value) C_WARN else C_IDLE)
        mini.accent = stateColor
        r.alpha = repo.current.panelOpacity
    }

    // ------------------------------------------------------------------

    private fun build() {
        val bg = GradientDrawable().apply {
            setColor(0xE61A1D24.toInt())
            cornerRadius = dp(14f).toFloat()
            setStroke(dp(1f), 0x334DD0E1)
        }

        tvState = indicator()
        tvObj = indicator()
        tvClick = indicator()
        val indicators = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4f), dp(2f), dp(4f), dp(2f))
            addView(tvState)
            addView(tvObj)
            addView(tvClick)
        }

        bPlay = button(Glyph.PLAY) { actions.onPlay() }
        bPause = button(Glyph.PAUSE) { actions.onPause() }
        bStop = button(Glyph.STOP) { actions.onStop() }
        val bSettings = button(Glyph.GEAR) { actions.onSettings() }
        val bMin = button(Glyph.MINIMIZE) {
            collapsed = true
            applyCollapsed()
        }
        val bHide = button(Glyph.CLOSE) { actions.onHide() }
        bMarker = button(Glyph.TARGET) { actions.onToggleMarker() }
        bRegion = button(Glyph.REGION) { actions.onToggleRegion() }
        bFrame = button(Glyph.EYE) { actions.onToggleFrame() }
        val bSnap = button(Glyph.CAMERA) { actions.onSnapshot() }

        expanded = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
            addView(indicators)
            addView(row(bPlay, bPause, bStop, bSettings, bMin, bHide))
            addView(row(bMarker, bRegion, bFrame, bSnap))
        }

        mini = GlyphButton(ctx, Glyph.TARGET).apply {
            isActivated = true
            setOnClickListener {
                collapsed = false
                applyCollapsed()
            }
        }

        val r = DragFrameLayout(ctx, { dx, dy -> moveBy(dx, dy) }, {})
        r.addView(expanded)
        r.addView(mini)

        val p = OverlayParams.make(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            dp(12f), dp(120f), touchable = true
        )
        try {
            wm.addView(r, p)
        } catch (e: Exception) {
            return
        }
        root = r
        params = p
        applyCollapsed()
    }

    private fun applyCollapsed() {
        expanded.visibility = if (collapsed) View.GONE else View.VISIBLE
        mini.visibility = if (collapsed) View.VISIBLE else View.GONE
        root?.post {
            val r = root
            val p = params
            if (r != null && p != null) {
                try {
                    wm.updateViewLayout(r, p)
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun moveBy(dx: Int, dy: Int) {
        val p = params ?: return
        val r = root ?: return
        val screen = AppRuntime.screen.value
        p.x = (p.x + dx).coerceIn(0, maxOf(0, screen.width - r.width))
        p.y = (p.y + dy).coerceIn(0, maxOf(0, screen.height - r.height))
        try {
            wm.updateViewLayout(r, p)
        } catch (_: Exception) {
        }
    }

    private fun button(g: Glyph, onClick: () -> Unit): GlyphButton =
        GlyphButton(ctx, g).apply { setOnClickListener { onClick() } }

    private fun row(vararg views: View): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in views) addView(v)
    }

    private fun indicator(): TextView = TextView(ctx).apply {
        textSize = 11f
        setTextColor(0xFFCCD2E0.toInt())
        setPadding(dp(4f), 0, dp(8f), 0)
    }

    private fun setIndicator(tv: TextView, label: String, color: Int) {
        val sp = SpannableString("● $label")
        sp.setSpan(ForegroundColorSpan(color), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        tv.text = sp
    }
}
